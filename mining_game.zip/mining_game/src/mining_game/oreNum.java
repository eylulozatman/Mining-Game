/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mining_game;

/**
 *
 * @author DELL
 */
public class oreNum 
{
        int totIron;
        int totCopper;
        int totDiamond;

    public oreNum(int totIron, int totCopper, int totDiamond) {
        this.totIron = 0;
        this.totCopper = 0;
        this.totDiamond = 0;
    }

    public int getTotIron() {
        return totIron;
    }

    public void setTotIron(int totIron) {
        this.totIron = totIron;
    }

    public int getTotCopper() {
        return totCopper;
    }

    public void setTotCopper(int totCopper) {
        this.totCopper = totCopper;
    }

    public int getTotDiamond() {
        return totDiamond;
    }

    public void setTotDiamond(int totDiamond) {
        this.totDiamond = totDiamond;
    }
        
        
              
}
