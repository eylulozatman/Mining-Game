/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mining_game;

/**
 *
 * @author DELL
 */
public class CharControls 
{
   
    public void JennyControls(game_screen gs)
    {
        java.util.Random x = new java.util.Random();
         int n = 1 + x.nextInt(10);
         int num = 1 + x.nextInt(10);
         String numm = String.valueOf(num);
         
       
        if(gs.count < 3)
        {
            gs.count++;
            if(n <= 5)
            {
              gs.irontot += num;
              gs.getIronlbl().setText(String.valueOf(gs.irontot));
             
              
            }
            else if(n <= 8 && n > 5)
            {
                gs.coptot += num;
              gs.getCoplbl().setText(String.valueOf(gs.coptot));
             
            }
            else
            {
                gs.diatot += num;
              gs.getDialbl().setText(String.valueOf(gs.getDiatot()));
             
            }
               
        }
    }
    public void JoeControls(game_screen gs)      
    {
      java.util.Random x = new java.util.Random();
         int n = 1 + x.nextInt(10);
         int num = 1 + x.nextInt(10);
         String numm = String.valueOf(num);
   
       
        if(gs.count < 3)
        {
            gs.count++;
            if(n <= 5)
            {
              gs.irontot += num;
              gs.getIronlbl().setText(String.valueOf(gs.irontot));
              
            }
            else if(n < 8 && n > 5)
            {
               gs.coptot += num;
              gs.getCoplbl().setText(String.valueOf(gs.coptot));
            }
            else
            {
                  gs.diatot += num;
              gs.getDialbl().setText(String.valueOf(gs.getDiatot()));
            }
               
        }   
    }
    public void RosieControls(game_screen gs)
    {
         java.util.Random x = new java.util.Random();
         int n = 1 + x.nextInt(10);
         int num = 1 + x.nextInt(10);
         String numm = String.valueOf(num);
        
      
        if(gs.count < 3)
        {
            gs.count++;
            if(n < 3)
            {
                gs.irontot += num;
                gs.getIronlbl().setText(String.valueOf(gs.irontot));
              
            }
            else if(n <= 7 && n >= 3)
            {
                gs.coptot += num;
              gs.getCoplbl().setText(String.valueOf(gs.coptot));
            }
            else
            {
               gs.diatot += num;
              gs.getDialbl().setText(String.valueOf(gs.getDiatot()));
            }
               
        }
    }
    public void MaxControls(game_screen gs)      
    {
         java.util.Random x = new java.util.Random();
         int n = 1 + x.nextInt(10);
         int num = 1 + x.nextInt(10);
         int dianum = 1 + x.nextInt(12);
         String numm = String.valueOf(num);
  
       
        if(gs.count < 3)
        {
            gs.count++;
            if(n <= 5)
            {
               gs.irontot += num;
                gs.getIronlbl().setText(String.valueOf(gs.irontot));
            }
            else if(n < 8 && n > 5)
            {
                 gs.coptot += num;
              gs.getCoplbl().setText(String.valueOf(gs.coptot));
            }
            else
            {
                gs.diatot += num;
              gs.getDialbl().setText(String.valueOf(gs.getDiatot()));
            }
               
        }
    }
    
        
    
        
    
}
